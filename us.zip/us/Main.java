import javax.swing.*;
import javax.swing.border.LineBorder;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.*;

public class Main extends JFrame implements ActionListener{
  JButton sofa, beds,dinning_table,login;
  JPanel sofaPanel, bedsPanel, dinPanel, loginPanel;
  Resizer resizer = new Resizer();
  public Main() {
    this.setSize(1370,850);
    this.setLocationRelativeTo(null);
    this.getContentPane().setBackground(Color.white);
    this.setTitle("OOP Furnitures");
    this.setLayout(null);
    
    this.setDefaultCloseOperation(EXIT_ON_CLOSE);
    
    JLabel title = new JLabel("\t\t\t\t\t\t OOP FURNITURES!");
    title.setFont(new Font("MONOSPACED", Font.BOLD, 40));
    title.setForeground(Color.white);
    title.setBackground(Color.decode("#25BE63"));
    title.setBounds(0, 0, 1400, 100);
    title.setOpaque(true);
    
    title.setHorizontalAlignment(SwingConstants.CENTER);
 
    
    
    


    ImageIcon sofaIcon = new ImageIcon("sofa.jpg");
    ImageIcon sofa_icon = resizer.resizeImageIcon(sofaIcon, 300,450);
    JLabel sofaLabel = new JLabel(sofa_icon);
    sofaLabel.setBounds(0, 0, 300,450);

    String multilineText = "<html>GET BEST EXPERIENCE OF YOUR SOFA!</html>";
    JLabel sofa_description = new JLabel(multilineText);
    sofa_description.setFont(new Font("SANS_SERIF", Font.BOLD, 20));
    sofa_description.setForeground(Color.white);
    sofa_description.setBounds(5, 440, 300, 120);

    sofa = new JButton("Watch Sofas");
    sofa.setBackground(Color.white);
    sofa.setFont(new Font("MONOSPACED", Font.BOLD, 25));
    sofa.setForeground(Color.decode("#1e81b0"));
    sofa.setBounds(0, 540, 300, 60);
    sofa.setFocusable(false);
    sofa.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
    sofa.addActionListener(this);
   

    sofaPanel = new JPanel();
    sofaPanel.setBounds(10, 100, 300, 600);
    sofaPanel.setBackground(Color.decode("#2596be"));
    sofaPanel.setForeground(Color.white);
    sofaPanel.add(sofaLabel);
    sofaPanel.setLayout(null);
    sofaPanel.add(sofa_description);
    sofaPanel.add(sofa);




    ImageIcon dinIcon = new ImageIcon("din1.jpg");
    ImageIcon din_icon = resizer.resizeImageIcon(dinIcon, 300,450);
    JLabel dinLabel = new JLabel(din_icon);
    dinLabel.setBounds(0, 0, 300,450);

    String din_text = "<html>GET THE BEST DINNING TABLE<br> ENJOY YOUR MEAL!</html>";
    JLabel din_description = new JLabel(din_text);
    din_description.setFont(new Font("SANS_SERIF", Font.BOLD, 20));
    din_description.setForeground(Color.white);
    din_description.setBounds(5, 440, 300, 120);

    dinning_table = new JButton("Dinning Tables");
    dinning_table.setBackground(Color.white);
    dinning_table.setFont(new Font("MONOSPACED", Font.BOLD, 25));
    dinning_table.setForeground(Color.decode("#1e81b0"));
    dinning_table.setBounds(0, 540, 300, 60);
    dinning_table.setFocusable(false);
    dinning_table.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
    dinning_table.addActionListener(this);
   

    dinPanel = new JPanel();
    dinPanel.setLayout(null);
    dinPanel.setBounds(320, 100, 300, 600);
    dinPanel.setBackground(Color.decode("#2596be"));
    dinPanel.setForeground(Color.white);
    dinPanel.add(dinLabel);

    dinPanel.add(din_description);
    dinPanel.add(dinning_table);


    ImageIcon chairIcon = new ImageIcon("bed1.jpg");
    ImageIcon chair_icon = resizer.resizeImageIcon(chairIcon, 300,450);
    JLabel chairLabel = new JLabel(chair_icon);
    chairLabel.setBounds(0, 0, 300,450);

    String Beds_text = "<html>CHECK OUT OUR DELUX BEDS!</html>";
    JLabel beds_description = new JLabel(Beds_text);
    beds_description.setFont(new Font("SANS_SERIF", Font.BOLD, 20));
    beds_description.setForeground(Color.white);
    beds_description.setBounds(5, 440, 300, 120);

    beds = new JButton("Beds");
    beds.setBackground(Color.white);
    beds.setFont(new Font("MONOSPACED", Font.BOLD, 25));
    beds.setForeground(Color.decode("#1e81b0"));
    beds.setBounds(0, 540, 300, 60);
    beds.setFocusable(false);
    beds.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
    beds.addActionListener(this);
   

    bedsPanel = new JPanel();
    bedsPanel.setLayout(null);
    bedsPanel.setBounds(630, 100, 300, 600);
    bedsPanel.setBackground(Color.decode("#2596be"));
    bedsPanel.setForeground(Color.white);
    bedsPanel.add(chairLabel);


    bedsPanel.add(beds_description);
    bedsPanel.add(beds);



    loginPanel = new JPanel();
    loginPanel.setLayout(null);
    loginPanel.setBounds(940, 100, 400, 600);
    loginPanel.setBackground(Color.decode("#2596be"));
    loginPanel.setForeground(Color.white);
    
    ImageIcon historyIcon = new ImageIcon("progress.jpg");
    ImageIcon hisory_icon = resizer.resizeImageIcon(historyIcon, 400,450);
    JLabel historyLabel = new JLabel(hisory_icon);
    historyLabel.setBounds(0, 0, 400,450);

    String history_text = "<html>WARNING<br> AUTHORIZED ACCESS ONLY!</html>";
    JLabel history_description = new JLabel(history_text);
    history_description.setFont(new Font("SANS_SERIF", Font.BOLD, 20));
    history_description.setForeground(Color.white);
    history_description.setBounds(5, 440, 400, 120);

    login = new JButton("Transaction History");
    login.setBackground(Color.white);
    login.setFont(new Font("MONOSPACED", Font.BOLD, 25));
    login.setForeground(Color.decode("#1e81b0"));
    login.setBounds(0, 540, 400, 60);
    login.setFocusable(false);
    login.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
    login.addActionListener(this);


    
    loginPanel.add(historyLabel);
    loginPanel.add(history_description);
    loginPanel.add(login);


    


    
    


    
  
    JLabel footer = new JLabel("CONTACT-- 0912345678 - oop@furnitures.com");
    footer.setFont(new Font("MONOSPACED", Font.BOLD, 40));
    footer.setForeground(Color.white);
    footer.setBackground(Color.decode("#25BE63"));
    footer.setBounds(0, 700, 1400, 90);
    footer.setOpaque(true);
    
    footer.setHorizontalAlignment(SwingConstants.CENTER);


    this.setResizable(false);
    this.add(title);
    this.add(sofaPanel);
    this.add(dinPanel);
    this.add(bedsPanel);
    this.add(loginPanel);
    this.add(footer);
    this.setVisible(true);
  }
  public void actionPerformed(ActionEvent e){
    if (e.getSource() == sofa){
      Sofa sofa = new Sofa();
      this.dispose();
    }
    if (e.getSource() == beds){
      Beds beds = new Beds();
      this.dispose();
    }
    if (e.getSource() == dinning_table){
      Dinning dinning = new Dinning();
      this.dispose();
    }
    if(e.getSource() == login){
      String userInput = JOptionPane.showInputDialog(this, "Enter your name:");

        // our password is "aait" for trial
        if (userInput.equalsIgnoreCase("aait")) {
          History history = new History();
          this.dispose();
        } else {
            JOptionPane.showMessageDialog(this, "incorrect passowrd\n the password is aait");
        }
    }
    }
  
  
  public static void main(String[] args) {
    
    Main myMain = new Main();
  }

}
